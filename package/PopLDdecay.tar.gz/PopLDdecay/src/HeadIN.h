
#ifndef HeadIN_H_
#define HeadIN_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <iomanip>
#include <math.h>
#include <cstdlib>
#include <zlib.h>
#include "./include/gzstream/gzstream.c"

#include "./DataClass.h"
#include "./CommFun.h"

#endif  // end HeadIN 


